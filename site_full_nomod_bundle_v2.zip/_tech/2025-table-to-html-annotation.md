---
title: "표 → HTML 구조 복원: 주석 스키마"
date: 2025-10-18
excerpt: "bbox_norm/px · reading_order · rowspan/colspan"
---
샘플 글 (실제 글로 교체하세요).

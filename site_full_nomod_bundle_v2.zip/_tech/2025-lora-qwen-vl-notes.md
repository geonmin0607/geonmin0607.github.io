---
title: "LoRA/QLoRA로 Qwen-VL 파인튜닝 메모"
date: 2025-10-18
excerpt: "멀티모달 파인튜닝 팁: 해상도 커리큘럼, 비전 프라이어"
---
샘플 글 (실제 글로 교체하세요).

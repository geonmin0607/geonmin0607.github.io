---
title: "About"
layout: single
permalink: /about/
classes: wide
---

AI 엔지니어 **GEONMIN LEE**의 포트폴리오입니다.  
문서·표·다이어그램 이해 및 **RAG/LLM 파이프라인**을 설계·구현하고, 파인튜닝/강화학습/평가까지 **엔드투엔드**로 다룹니다.

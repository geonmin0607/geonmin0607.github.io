---
layout: collection
title: "Patents"
collection: patents
entries_layout: grid
permalink: /patents/
classes: wide
---
